import CmsPage from '@/components/shared/CmsPage';

export default function ContactPage() {
  return <CmsPage title="Contact Us" seoUrl="contact-us" />;
}
